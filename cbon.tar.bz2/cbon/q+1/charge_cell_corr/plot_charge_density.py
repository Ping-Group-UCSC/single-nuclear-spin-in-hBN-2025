#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import os

plt.rcParams["figure.titlesize"] = 20
plt.rcParams["lines.linewidth"] = 2
plt.rcParams["xtick.labelsize"] = 20
plt.rcParams["ytick.labelsize"] = 20
plt.rcParams["font.size"] = 20
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = "Arial"
plt.rcParams["legend.fontsize"] = 20
plt.rcParams["figure.figsize"] = (8, 6)
plt.rcParams["figure.dpi"] = 100

def plot_charge_density(dir_f, fft):

    # read d_tot (total electrostatic potential, 3D)
    charge_n = np.fromfile(dir_f, dtype=np.float64).reshape(fft)

    # average in z direction (out-of-plane)
    charge_n = np.average(charge_n, axis=(1, 0))

    # z-length
    z = np.arange(fft[2]) / fft[2] * 30
    return(z, charge_n)


if __name__ == "__main__":
    cwd = os.getcwd()
    charges = ["q+1", "q-1", "q+2", "q-2"]

    fft = (144, 144, 144) # c2cn, c2cb

    fig, ax = plt.subplots(nrows=1, ncols=1, constrained_layout=True)
    p = os.path.join(cwd, "pristine/jdftx/charge.n_up")


    for i, q in enumerate(charges):
        p = os.path.join(cwd, q, "ccc/bnjdftx.n_up")
#        p = os.path.join(cwd, q, "ccc/charge.n_dn")
        z, charge_n = plot_charge_density(p, fft)
        ax.plot(z, charge_n, label=q)
    
    
    ax.legend()
    
    ax.set_ylabel("$\\rho$ (a.u.)")
    plt.xlabel("z (A)")
    plt.show()
    plt.savefig("charge.png")

