#!/usr/bin/env python3
import sys
import numpy as np
import os
import re
import argparse
import matplotlib.pyplot as plt

def read_vac(dir_f=".avg.out"):
    """
    ++--------------------------------------------------------------------------
    +   Read electrostatic potential file avg.out
    +   electrostatic potential data start from line 23 and stop at line -10
    +
    +   return(z, vac)
    +   z: positions in z of cell (angstrom)
    +   vac: vacuum electrostatic potential (eV)
    ++--------------------------------------------------------------------------
    """
    f = open(dir_f, "r")
    lines = f.readlines()
    z = []
    vac = []
    found_vac = False
    for i, line in enumerate(lines):
        if "Reading data from file  bn.pot" in line and not found_vac:
            found_vac = True
            continue
        elif "AVERAGE      :" in line:
            break
        elif found_vac and line.strip():
            z.append(float(re.findall(r"[+-]?\d+\.\d*", line)[0]))
            vac.append(float(re.findall(r"[+-]?\d+\.\d*", line)[1]))
        elif found_vac and not line.strip():
            continue
    
    # physical constants
    Bohr = 5.29177210903e-11 # unit m
    Bohr2Ang = Bohr/1e-10
    Ry = 2.1798723611035e-18 # Rydberg in Joules
    Ry2eV = 13.605693122994 # Rydberg constant in eV

    z = np.asarray(z) * Bohr2Ang
    vac = np.asarray(vac) * Ry2eV
    return(z, vac)


if __name__ == "__main__":
    cwd = os.getcwd()
    f = os.path.join(cwd, "avg.dat")
    data = np.loadtxt(f)
    z = data[:, 0] * 5.29177210903e-11/1e-10
    vac = data[:, 2] * 13.605693122994
    plt.plot(z, vac)
    plt.xlabel("z (A)")
    plt.ylabel("pot (eV)")
    plt.ylim(-40, 3)
    plt.savefig("vac.png")
